package TAHAP2PEMLAN;

public class Perusahaan {
    final String NAMA_PERUSAHAAN = "PT. Inovasi Teknologi";
    
    
    public String getnamaPerushaan(){
        return NAMA_PERUSAHAAN;
    }
    
}
